const alunos = [
  {
    id: 1,
    nome: 'Amanda Ferreira',
    ra: '2024001',
    faltas: 2,
    aulas: 20
  },
  {
    id: 2,
    nome: 'Bruno Oliveira',
    ra: '2024002',
    faltas: 8,
    aulas: 20
  },
  {
    id: 3,
    nome: 'Camila Santos',
    ra: '2024003',
    faltas: 1,
    aulas: 20
  },
  {
    id: 4,
    nome: 'Diego Martins',
    ra: '2024004',
    faltas: 5,
    aulas: 20
  },
  {
    id: 5,
    nome: 'Eduarda Lima',
    ra: '2024005',
    faltas: 0,
    aulas: 20
  }
];