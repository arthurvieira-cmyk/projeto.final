// Funções de Autenticação e Fluxo
function efetuarLogin() {
  const email = document.getElementById('loginEmail').value;
  const pass = document.getElementById('loginPass').value;

  // Simulação simples de login
  if (email !== "" && pass !== "") {
    document.getElementById('login-page').style.display = 'none';
    document.getElementById('setup-page').style.display = 'flex';
  } else {
    alert("Por favor, preencha as credenciais.");
  }
}

function confirmarSetup() {
  const curso = document.getElementById('selectCurso').value;
  const sala = document.getElementById('selectSala').value;

  // Salva e exibe as informações na tela principal
  document.getElementById('displayCurso').textContent = curso;
  document.getElementById('displaySala').textContent = sala;

  // Transição de tela
  document.getElementById('setup-page').style.display = 'none';
  document.getElementById('main-app').style.display = 'flex';
  
  // Inicia o sistema
  renderStudents();
}

// Opcional: Adicionar função de Logout
function logout() {
    window.location.reload();
}